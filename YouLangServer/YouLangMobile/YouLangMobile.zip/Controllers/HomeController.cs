﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using Newtonsoft.Json;
using YouLangMobile.API;

namespace YouLangMobile.Controllers
{
    public class HomeController : Controller
    {
        private Dictionary<string, string> db = new Dictionary<string, string>();

        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public string Login()
        {
            return "Hello!";
        }

        [HttpPost]
        public string Login(string credentials)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ulangdb"].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            var user = JsonConvert.DeserializeObject<Credentials>(credentials);

            try
            {
                SqlDataReader sqlReader = null;

                SqlCommand command = new SqlCommand("SELECT [name], [password] FROM [users]", sqlConnection);

                db.Clear();

                sqlReader = command.ExecuteReader();

                while (sqlReader.Read())
                {
                    db.Add(Convert.ToString(sqlReader["name"]), Convert.ToString(sqlReader["password"]));
                }

                sqlReader.Close();

                if (user.Password == db[user.Login])
                {
                    return "ok";
                }
                else
                {
                    if (sqlConnection != null && sqlConnection.State != ConnectionState.Closed)
                        sqlConnection.Close();

                    return "Неправильный логин или пароль!";
                }
            }
            catch (Exception)
            {
                if (sqlConnection != null && sqlConnection.State != ConnectionState.Closed)
                    sqlConnection.Close();

                return "Неверный формат данных!";
            }
        }
    }
}